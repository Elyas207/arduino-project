TEA5767
=======

Arduino library for the TEA5767 Philips radio module written in C++. Tested with Arduino Leonardo.

Files and folder

File deploy.bat
	Copy files TEA5767N.cpp and TEA5767N.h to the Arduino thirdparty libraries folder.
	
Folder examples
	LCDKeyPadShieldAndRadioTEA5767Demo
		Complete application 
		
	SimpleLibDemo
		Performs consecutive calls to several radio methods, demonstrating main features.
		
	SimpleRadioStationSelection
		Simple application selecting a single frequency.